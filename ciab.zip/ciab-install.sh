#!/bin/bash

clear

INSTALL_DIR="/opt/ciab"
UBUNTU_VER=20.04


#==================================================================================================================================
# ciab-install.sh
#
# Purpuse:
#
# This script will create 2 LXD containers "ciab-cn1" and "ciab-guac"
#
# ciab-guac:
#
# 1) will be created with nesting "enabled" so we can install both docker and docker-compose nested inside ciab-guac.
# 2) will also use docker-compose to install an implementation of Guacamole that includes:
#    -- Guacamole
#    -- Tomcat9
#    -- Mysql
#    -- NGINX
#
# 3) it will also setup NGINX to utilize a "self-signed" certificate so that Client HTML5 Browsers can
#    connect with HTML5 HTTPS and not HTTP.   This enables encryption from a user's browser to their
#    connection with CIAB's Guacamole
#
# The creation of the ciab-cn1 LXD container will present the Installer with a menu from which they can select
# which Desktop Environment (KDE, XFCE, Gnome, Mate, Budgie etc) to install.
#
# it will also install the latest XRDP into ciab-cn1 and configure it to support audio "redirect" via Pulseaudio
# so the remote Client user can hear audio
#==================================================================================================================================


echo
echo "===={ BEGIN }================================================================================================================"
echo
echo "NOTE:  This script should NOT be executed as SUDO or ROOT .. but as your 'normal' UserID"
echo
echo "Checking if this script was axecuted as either Root or Sudo ... if it was then it will exit and you can try again."

echo
echo
if [ $(id -u) = 0 ]; then echo "Do NOT run this script SUDO or ROOT... please run as your normal UserID !"; exit 1 ; fi
echo
echo

#====================================================================================================================================
# update/upgrade system before we start

sudo apt-get update && sudo apt-get upgrade -y


cd $INSTALL_DIR

sleep  2

echo
echo
echo "==============================================================================================================================="
echo " Creating our an initial CIAB Desktop LXD Containers"
echo
echo " We will also create an initial User Account in each container for whoever is Installing CIAB."
echo "==============================================================================================================================="

lxc launch ubuntu:$UBUNTU_VER ciab-cn1
sleep 3
lxc config set ciab-cn1 boot.autostart 1

echo
echo "=============================================================================================================================="
echo "Updating and Upgrade ciab-cn1 container"
echo

CMD="apt-get update"
lxc exec ciab-cn1 -- $CMD
sleep 5

CMD="apt-get upgrade -y"
lxc exec ciab-cn1 -- $CMD
sleep 5

echo
echo "=============================================================================================================================="
echo "creating a temp directory '/opt/ciab' to hold any specific install scripts related to that container's purpose"
echo

CMD="mkdir $INSTALL_DIR"

lxc exec ciab-cn1 -- $CMD

echo
echo "=============================================================================================================================="
echo "Setting up \"ciab-cn1\" with installation files by placing them in /opt/ciab inside the ciab-cn1 container then executing them"
echo
echo

CMD="sudo apt-get install unzip -y"
lxc exec ciab-cn1 -- $CMD
sleep 5

echo
echo "=============================================================================================================================="
echo
echo " Create a UserAccount for the Installer UserID in ciab-cn1 container and give it Sudo and ADM privileges."
echo
echo "=============================================================================================================================="
echo
echo

CMD="sudo adduser $USER"
lxc exec ciab-cn1 -- $CMD

CMD="sudo adduser $USER adm"
lxc exec ciab-cn1 -- $CMD

CMD="sudo adduser $USER sudo"
lxc exec ciab-cn1 -- $CMD

CMD="chown -R $USER:$USER $INSTALL_DIR"
lxc exec ciab-cn1 -- $CMD

CMD="chmod -R 766 $INSTALL_DIR"
lxc exec ciab-cn1 -- $CMD

CMD="$INSTALL_DIR/mk-userid.sh"
lxc exec ciab-cn1 -- $CMD

lxc stop ciab-cn1 --force
sleep 4

#==================================================================================================================================
# copy ciab-cn1 to ciab-guac

lxc copy ciab-cn1 ciab-guac
sleep 5

lxc file push $INSTALL_DIR/ciab-cn1.zip ciab-cn1/$INSTALL_DIR/

lxc start ciab-cn1
sleep 4

CMD="sudo unzip $INSTALL_DIR/ciab-cn1.zip -d $INSTALL_DIR/"
lxc exec ciab-cn1 -- $CMD
sleep 4

lxc config device add ciab-guac proxyport443 proxy listen=tcp:0.0.0.0:443 connect=tcp:127.0.0.1:8443

lxc config set ciab-guac security.nesting true
sleep 2

lxc start ciab-guac
sleep 3

lxc file push $INSTALL_DIR/ciab-guac.zip ciab-guac/$INSTALL_DIR/

CMD="sudo unzip $INSTALL_DIR/ciab-guac.zip -d $INSTALL_DIR/"
lxc exec ciab-guac -- $CMD


#========================================================================================================================
# Install CIAB Remote Desktop in ciab-cn1

CMD="su $USER $INSTALL_DIR/setup-ciab-cn1.sh"
lxc exec ciab-cn1 -- $CMD

#========================================================================================================================
# Install CIAB Dockerized Guacamole in ciab-guac

CMD="su $USER $INSTALL_DIR/setup-ciab-guac.sh"
lxc exec ciab-guac -- $CMD

