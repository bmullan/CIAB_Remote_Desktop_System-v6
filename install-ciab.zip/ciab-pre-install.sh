#!/bin/bash


clear


INSTALL_DIR=/opt/ciab

#==================================================================================================================================
# ciab-pre-install.sh
#
# Purpuse:
#
# This script will make sure we start with a clean LXD
#==================================================================================================================================


echo
echo "===={ BEGIN }================================================================================================================"
echo
echo "NOTE:  This script should NOT be executed as SUDO or ROOT .. but as your 'normal' UserID"
echo
echo "Checking if this script was axecuted as either Root or Sudo ... if it was then it will exit and you can try again."

echo
echo
if [ $(id -u) = 0 ]; then echo "Do NOT run this script SUDO or ROOT... please run as your normal UserID !"; exit 1 ; fi
echo
echo

echo
echo "==============================================================================================================================="
echo " Uninstall any pre-installed LXD and reinstall and re-init using an LXD Init Preseed Yaml config file so answers are all" 
echo " automated.   Note LXD may not be pre-installed but this makes sure that its configured how we want it.   Primarily due"
echo " to working around the problem that both Docker and LXD 'over the network' both default to Port 8443."
echo
echo " So we setup LXD to use Port 8445 instead for LXD access over the network."
echo
echo 

cd $INSTALL_DIR

sudo apt-get purge lxd
sudo apt-get install snapd 
sudo snap remove lxd
sudo snap install lxd 

#===================================================================================================================================="
# if you ever just want LXD to auto-configure a cmd line like this would do it...
#
# $ sudo lxd init --preseed < ./ciab-lxd-init-preseed.yaml
#

sudo lxd init

#===================================================================================================================================="
# Adding the Installer's UserID to the LXD group to enable use of lxc cli

sudo adduser $USER lxd
sleep 2

clear
echo
echo "==============================================================================================================================="
echo " Next step is to begin the CIAB installation..."
echo 
echo " At the command prompt Execute:"
echo
echo "       \"./ciab-install.sh\""
echo
echo

newgrp lxd


