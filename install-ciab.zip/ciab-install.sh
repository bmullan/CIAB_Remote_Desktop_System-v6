#!/bin/bash


clear


INSTALL_DIR=/opt/ciab


#==================================================================================================================================
# Log the script execution

exec > >(tee -i ./ciab-install.log)
exec 2>&1

#==================================================================================================================================
# install-ciab.sh
#
# Purpuse:
#
# This script will create 2 LXD containers "ciab-cn1" and "ciab-guac"
#
# ciab-guac:
#
# 1) will be created with nesting "enabled" so we can install both docker and docker-compose nested inside ciab-guac.
# 2) will also use docker-compose to install an implementation of Guacamole that includes:
#    -- Guacamole
#    -- Tomcat9
#    -- Mysql
#    -- NGINX
#
# 3) it will also setup NGINX to utilize a "self-signed" certificate so that Client HTML5 Browsers can
#    connect with HTML5 HTTPS and not HTTP.   This enables encryption from a user's browser to their
#    connection with CIAB's Guacamole
#
# The creation of the ciab-cn1 LXD container will present the Installer with a menu from which they can select
# which Desktop Environment (KDE, XFCE, Gnome, Mate, Budgie) to install.
#
# it will also install the latest XRDP into ciab-cn1 and configure it to support audio "redirect" via Pulseaudio
# so the remote Client user can hear audio
#==================================================================================================================================


echo
echo "===={ BEGIN }================================================================================================================"
echo
echo "NOTE:  This script should NOT be executed as SUDO or ROOT .. but as your 'normal' UserID"
echo
echo "Checking if this script was axecuted as either Root or Sudo ... if it was then it will exit and you can try again."

echo
echo
if [ $(id -u) = 0 ]; then echo "Do NOT run this script SUDO or ROOT... please run as your normal UserID !"; exit 1 ; fi
echo
echo

echo
echo "==============================================================================================================================="
echo " Uninstall any pre-installed LXD and reinstall and re-init using an LXD Init Preseed Yaml config file so answers are all" 
echo " automated.   Note LXD may not be pre-installed but this makes sure that its configured how we want it.   Primarily due"
echo " to working around the problem that both Docker and LXD 'over the network' both default to Port 8443."
echo
echo " So we setup LXD to use Port 8445 instead for LXD access over the network."
echo
echo 

cd $INSTALL_DIR

sleep  2

echo
echo
echo "==============================================================================================================================="
echo "Creating our two CIAB LXD Containers..."
echo

CMD="security.nesting=true"

echo
echo $CMD
echo

lxc launch ubuntu:20.04 ciab-guac -c $CMD

lxc launch ubuntu:20.04 ciab-cn1

# wait approx 10 sec so those containers get fully created & have an IP

sleep 10

echo
echo "=============================================================================================================================="
echo "Updating and Upgrading both containers..."
echo

CMD="apt-get update"

lxc exec ciab-guac -- $CMD

lxc exec ciab-cn1 -- $CMD


CMD="apt-get upgrade -y"

lxc exec ciab-guac -- $CMD

lxc exec ciab-cn1 -- $CMD


echo
echo "=============================================================================================================================="
echo "creating a temp directory '/opt/ciab' to hold any specific install scripts related to that container's purpose"
echo

CMD="mkdir $INSTALL_DIR"

lxc exec ciab-guac -- $CMD

lxc exec ciab-cn1 -- $CMD

echo
echo "=============================================================================================================================="
echo "Setting up \"ciab-cn1\" with installation files by placing them in /opt/ciab inside the ciab-cn1 container..."
echo
echo

lxc file push ./ciab-cn1.zip ciab-cn1/opt/ciab/

CMD="apt-get install unzip -y"

lxc exec ciab-cn1 -- $CMD

CMD="unzip $INSTALL_DIR/ciab-cn1.zip -d $INSTALL_DIR/"
lxc exec ciab-cn1 -- $CMD

CMD="chmod 766 $INSTALL_DIR/*.sh"
lxc exec ciab-cn1 -- $CMD

echo
echo "=============================================================================================================================="
echo "Setting up \"ciab-guac\" with installation files by placing them in /opt/ciab inside the ciab-guac container..."
echo
echo

lxc file push ./ciab-guac.zip ciab-guac/opt/ciab/

CMD="apt-get install unzip -y"

lxc exec ciab-guac -- $CMD

CMD="unzip $INSTALL_DIR/ciab-guac.zip -d $INSTALL_DIR/"
lxc exec ciab-guac -- $CMD

CMD="chmod 766 $INSTALL_DIR/*.sh"
lxc exec ciab-guac -- $CMD

echo
echo
echo "=============================================================================================================================="
echo " Use LXD to forward incoming Port 443 (re https) to the ciab-guac container"
echo " proxy port 443 on host to ciab-guac so a web browser trying to connect via port 443 (ie https/tls)"
echo " can connect to the guacamole web server running in ciab-guac container"
echo
echo " The Dockerized Guacamole is configured to listen on Port 8443 so we simplify things an just let the CIAB Users"
echo " to point to the Host Server/VM's IP using HTTPS (re Port 443) and use LXD Proxy Device to redirect that to "
echo " Port 8443 in the ciab-guac LXD container... which is where the Dockerized Guacamole is running as a \"nested\" container"

lxc config device add ciab-guac proxyport443 proxy listen=tcp:0.0.0.0:443 connect=tcp:127.0.0.1:8443




































